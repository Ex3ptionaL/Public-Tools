# CC-Checker
CC-Checker based by sk_key stripe

# Configuration
Change line 101 to your sk key

install all requirements

      pip install requests names
      
if you don't have sk_key you can check on http://44.202.162.254/
