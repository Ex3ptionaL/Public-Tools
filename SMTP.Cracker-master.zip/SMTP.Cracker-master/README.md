<h1>SMTP - Mail access Cracker</h1>
<p><a href="https://github.com/aron-tn/SMTP-Mail.acess-Cracker-Checker"><img src="https://img.shields.io/badge/Supported%20OS-windows%2FLinux%2Fandroid-blue.svg" alt="Build" data-canonical-src="https://img.shields.io/badge/Supported%20OS-windows%2FLinux%2Fandroid-blue.svg" style="max-width:100%;"></a></p>
<p>SMTP / Mail access Cracker ☣ Scanner & check & send to email <br>You can use this tool to crack smtp | mail access
<br>Combo Accepted : Email:pass
</p>

<h2>SMTP / Mail access Cracker</h2>

SMTP / Mail access Cracker ☣ Scanner & check & send to email

<img src="https://i.imgur.com/ozqA1U8.png" data-canonical-src="https://i.imgur.com/ozqA1U8.png" style="max-width:100%;">
<img src="https://i.imgur.com/gBX9a2o.png" data-canonical-src="https://i.imgur.com/gBX9a2o.png" style="max-width:100%;">


<h2>Video</h2>
<a href="https://www.youtube.com/watch?v=RvT_BMRQZvw&feature=youtu.be"><fontcolor='red'>Click Here </font></a>

<h2>📧 Contact</h2>
<li>You Want Ask About All My Tools Or Buy Tools Private Add Me On Facebook : fb.com/amir.othman.official</li>
<hr>

## Installation [Linux](https://wikipedia.org/wiki/Linux) [![alt tag](http://icons.iconarchive.com/icons/dakirby309/simply-styled/32/OS-Linux-icon.png)](https://fr.wikipedia.org/wiki/Linux)

```bash
cd Desktop
git clone https://github.com/aron-tn/SMTP.Cracker
cd SMTP.Cracker
python2 smtp.py
```

## Installation [Android](https://wikipedia.org/wiki/Android) [![alt tag](https://cdn1.iconfinder.com/data/icons/logotypes/32/android-32.png)](https://fr.wikipedia.org/wiki/Android)

Download [Termux](https://play.google.com/store/apps/details?id=com.termux)

```bash
git clone https://github.com/aron-tn/SMTP.Cracker
cd SMTP.Cracker
python2 smtp.py
```
## Installation [Windows ](https://wikipedia.org/wiki/Microsoft_Windows)[![alt tag](http://icons.iconarchive.com/icons/tatice/cristal-intense/32/Windows-icon.png)](https://fr.wikipedia.org/wiki/Microsoft_Windows)

Download [cmder](https://github.com/cmderdev/cmder/releases/download/v1.3.11/cmder.zip)

```bash
cd Desktop
git clone https://github.com/aron-tn/SMTP.Cracker
cd SMTP.Cracker
smtp.py
```
