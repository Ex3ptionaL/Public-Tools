#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests, httplib, urllib
import socket
from platform import system
import os
import sys, time
import re
from colorama import Fore								
from colorama import Style								
from colorama import init												
init(autoreset=True)
fr  =   Fore.RED
fh  =   Fore.RED
fc  =   Fore.CYAN
fo  =   Fore.MAGENTA
fw  =   Fore.WHITE
fy  =   Fore.YELLOW
fbl =   Fore.BLUE
fg  =   Fore.GREEN											
sd  =   Style.DIM
fb  =   Fore.RESET
sn  =   Style.NORMAL										
sb  =   Style.BRIGHT

user = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0"}

url_1 = "http://www.zone-h.org/archive/notifier="
url_2 = "http://zone-h.org/archive/published=0"
my_cook = {
	"ZHE" : "ea0d9a1e6611f4d961aed1542345c558",
	"PHPSESSID" : "g41ba307g9vh48puo37jcpaa11"
	}


def zone_h():
	print("""
	    |---| Grabbing Sites From Zone-h |--|
		\033[91m[1] \033[95mBy Notifier (target a specific notifier)
		\033[91m[2] \033[95mBy Onhold   (grabing the newest urls)
		""")
	sec = int(raw_input("Please select your choice : "))
	if sec == 1:
		notf = raw_input("\033[95mNotifier name: \033[92m")

		for i in range(1, 51):
			yonix = requests.get(url_1 + notf +"/page=" + str(i), cookies=my_cook)
			maniac = yonix.content
			print(url_1 + notf +"/page=" + str(i))
			if '<html><body>-<script type="text/javascript"' in maniac:
				print("Change Cookies Please")
				sys.exit()
			elif '<input type="text" name="captcha" value=""><input type="submit">' in maniac:
				print("Entre Captcha In Zone-h From Ur Browser :/")
				sys.exit()	
			else:
				Hunt_urls = re.findall('<td>(.*)\n							</td>', maniac)
				if '/mirror/id/' in maniac:
					for xx in Hunt_urls:
						qqq = xx.replace('...','')
						print '    ['  + '*' + '] ' + qqq.split('/')[0]
						with open( notf + '.txt', 'a') as rr:
							rr.write("http://" + qqq.split('/')[0] + '\n')
				else:
					print("Done Grabbing !")
					sys.exit()
					
	elif sec == 2:
		print("Starting Grabbing sites ! :)")
		for qwd in range(1, 51):
			rb = requests.get(url_2 + "/page=" + str(qwd) , cookies=my_cook)
			dzq = rb.content

			if '<html><body>-<script type="text/javascript"' in dzq:
				print("Please Update the ZHE & PHPSESSID")
				sys.exit()
				
			elif "captcha" in dzq:
				print("Please open [zone-h.org] in any browser & enter the captcha")
			else:
				Hunt_urlss = re.findall('<td>(.*)\n							</td>', dzq)
				for xxx in Hunt_urlss:
					qqqq = xxx.replace('...','')
					print '    ['  + '*' + '] ' + qqqq.split('/')[0]
					with open('onhold_zone.txt', 'a') as rrr:
						rrr.write("http://" + qqqq.split('/')[0] + '\n')
	else:
		print("Try again")
        
def clearscreen():
    if system() == 'Linux':
        os.system('clear')
    if system() == 'Windows':
        os.system('cls')
        os.system('color a')
clearscreen()

def main():
	clearscreen()
	banner = """\033[94m
  \x1B[32m
    ______                       _    _ 
   |___  /                      | |  | |
      / / ___  _ __   ___ ______| |__| |
     / / / _ \| '_ \ / _ \______|  __  |
    / /_| (_) | | | |  __/      | |  | |
   /_____\___/|_| |_|\___|      |_|  |_|Version 1.0\033[1;0m \033[1;0m
    Telegram : @YonixManiac       ICQ : @YonixManiac
	"""
	print("""\x1B[32m
    ______                       _    _ 
   |___  /                      | |  | |
      / / ___  _ __   ___ ______| |__| |
     / / / _ \| '_ \ / _ \______|  __  |
    / /_| (_) | | | |  __/      | |  | |
   /_____\___/|_| |_|\___|      |_|  |_|Version 1.0\033[1;0m \033[1;0m""")
   
	print("\nFast Links zone-h grabber" + "\n Telegram : @YonixManiac       ICQ : @YonixManiac")
	print("")
	print("""
		\033[91m[1] \033[95mGrab Sites  \033[92m From Zone-h.org   |
			""")		
	try:
		choice = int(raw_input("\033[91m[-] \033[90m\033[92mType 1 to continue\033[95m : \033[90m"))
		if choice == 1:
			clearscreen()
			print(banner)
			zone_h()
	except:
		pass
main()